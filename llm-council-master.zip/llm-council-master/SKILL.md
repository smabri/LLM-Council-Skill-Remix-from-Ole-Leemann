---
name: llm-council
version: 1.0.0
description: "Expert assistant for Karpathy's llm-council app — a local web app that sends queries to multiple LLMs via OpenRouter, has them review each other, and produces a Chairman synthesis. Helps with setup, configuration, debugging, and modification."
---

# LLM Council Skill

## What This Skill Is For
You are an expert assistant for **karpathy/llm-council** — a local web app that:
1. Sends a user query to multiple LLMs simultaneously via OpenRouter
2. Has each LLM anonymously review and rank the others' responses
3. Uses a designated "Chairman" LLM to synthesize a final answer

The app is a Python (FastAPI) backend + React/Vite frontend. It is a local-only app and is NOT deployed to the cloud.

---

## Project Structure

```
llm-council/
├── backend/
│   ├── main.py          # FastAPI app entry point
│   └── config.py        # COUNCIL_MODELS and CHAIRMAN_MODEL live here
├── frontend/            # React + Vite frontend
├── data/conversations/  # JSON storage for conversation history
├── main.py              # Top-level runner
├── start.sh             # Convenience script to run both servers
├── pyproject.toml       # Python deps managed by uv
└── .env                 # User-created; holds OPENROUTER_API_KEY
```

---

## Setup Instructions (give these when user asks how to run it)

### 1. Clone the repo
```bash
git clone https://github.com/karpathy/llm-council.git
cd llm-council
```

### 2. Install backend deps (requires `uv`)
```bash
uv sync
```
If `uv` is not installed: `pip install uv` or visit https://github.com/astral-sh/uv

### 3. Install frontend deps
```bash
cd frontend
npm install
cd ..
```

### 4. Create `.env` file in project root
```
OPENROUTER_API_KEY=sk-or-v1-...
```
Get a key at https://openrouter.ai — purchase credits or enable auto top-up.

### 5. Run the app
```bash
./start.sh
```
Or manually:
- Terminal 1: `uv run python -m backend.main`
- Terminal 2: `cd frontend && npm run dev`

Open http://localhost:5173 in your browser.

---

## Key Configuration (backend/config.py)

```python
COUNCIL_MODELS = [
    "openai/gpt-4o",
    "google/gemini-pro",
    "anthropic/claude-3-5-sonnet",
    "x-ai/grok-2",
]

CHAIRMAN_MODEL = "google/gemini-pro"
```

- **COUNCIL_MODELS**: The LLMs that participate in Stage 1 (first opinions) and Stage 2 (peer review). Add or remove any OpenRouter-supported model string.
- **CHAIRMAN_MODEL**: The LLM that synthesizes the final answer in Stage 3. Can be one of the council members or a separate model.

To find valid model strings: https://openrouter.ai/models

---

## How the 3-Stage Pipeline Works

| Stage | What Happens |
|-------|-------------|
| **Stage 1: First Opinions** | Query sent to all council models individually. Responses shown in a tab view. |
| **Stage 2: Peer Review** | Each model receives all other responses (anonymized). Asked to rank by accuracy and insight. |
| **Stage 3: Chairman Synthesis** | Chairman model receives all responses + rankings and produces one final answer. |

---

## Common Tasks You Can Help With

### Adding a new model
Edit `backend/config.py` and add the model string to `COUNCIL_MODELS`. Use OpenRouter model IDs (e.g. `"meta-llama/llama-3.1-70b-instruct"`).

### Changing the Chairman
Set `CHAIRMAN_MODEL` in `backend/config.py` to any valid OpenRouter model string.

### Debugging API key issues
- Confirm `.env` exists in the project root (not inside `backend/` or `frontend/`)
- Confirm the key starts with `sk-or-v1-`
- Check OpenRouter dashboard for credit balance

### Frontend not loading
- Confirm `npm install` completed without errors in `frontend/`
- Confirm the backend is running on its expected port
- Check for port conflicts on 5173

### Modifying the review prompt
Look in `backend/main.py` for the prompt template used in Stage 2. The anonymization logic is also there.

---

## Tech Stack Summary
- **Backend**: FastAPI, async httpx, Python 3.10+
- **Frontend**: React, Vite, react-markdown
- **LLM Access**: OpenRouter API (unified key for all providers)
- **Storage**: Local JSON files in `data/conversations/`
- **Package mgmt**: `uv` (Python), `npm` (JS)

---

## Important Caveats
- This is a **vibe-coded Saturday hack** by Karpathy. It is not production software and is not actively maintained.
- It runs **locally only** — there is no hosted version.
- You need an **OpenRouter API key with credits** — each query hits multiple LLMs and costs accordingly.
- Model strings in config must match OpenRouter's naming exactly or requests will fail.
